MegaRAID Storage Manager(MSM) Installation
==========================================

The kit contains both mode of installation. The interactive and non-interactive.
To, install the product using interactive mode, the user should execute the command "./install.csh" from the installation disk.
To, install the product in a non-interactive or silent mode, the user may use the command "./install.csh [-options] [ -ru popup]" from the installation disk. The options are:
  a, for Complete installation
  c, for Client Component Only
  s, for StandAlone
  l, for Local
The "-ru popup" will remove popup from installation list.
User may also run non-interactive installation using "RunRPM.sh" command.

The installer provides the user with three types of setup option.
1. Complete - This will install all the features of the product.
2. Client Components Only - The storelib feature of the product will not be installed in this type of installation. As a result, the resident system will only be able to administer and configure all the servers in the subnet, but will not be able to serve as a server.
3. StandAlone - This option will only install components required for local server management. This system will not be discovered automatically by other MSM
   servers in the subnet and it will not discover other MSM servers in the subnet automatically. (multicasting will be disabled) But the system can connect 
   to other MSM servers by providing the ipaddress in the hostview screen and can be connected by the other MSM clients in the subnet.
4. Local - This option will install only components required for local configuration. Will not allow other systems on the network to connect to
   this server and cannot connect to other servers. This MSM installation mode only uses the loopback interface.


The installation will help the user to select any of the setup type, but if the user directly run "RunRPM.sh", it will install the complete feature.

NOTE:
	1. For RHEL 5, it is necessary to install compat-libstdc++ version 33-3.x before installing rpm.
	2. For SLES-10 SP3 64bit OS, it is necessary to install libstdc++33-32bit-3.3.3-7.8.1.x86_64.rpm 
	   before installing MSM. This RPM is available in the OS DVD 
	   (path is /media/SUSE-Linux-Enterprise-Server_001/suse/x86_64)
	3. For SLES-9 32bit OS, it is necessary to install compat-libstdc++-lsb-4.0.2_20050901-0.4.i586.rpm
	   before installing MSM. This RPM is available in the OS DVD (path is /media/dvd/suse/i586)
	4. For RHEL 3, it is necessary to install the RPM libstdc++34-3.4.0-1.i386 before installing MSM.
	5. It is necessary to enable shadow password in RHEL 6 to login to MSM.
	6. Prerequisites for installing MSM on RHEL6.0 x64 operating system 
	   Before installing MSM on RHEL6.0 x64 system, Please install the following rpms,
	   Without these files/RPM's MSM may not be install properly or may not work as expected.

		libstdc++-4.4.4-13.el6.i686.rpm
		compat-libstdc++-33-3.2.3-69.i686.rpm
		libXau-1.0.5-1.el6.i686.rpm
		libxcb-1.5-1.el6.i686.rpm
		libX11-1.3-2.el6.i686.rpm
		libXext-1.1-3.el6.i686.rpm
		libXi-1.3-3.el6.i686.rpm
		libXtst-1.0.99.2-3.el6.i686.rpm
		
	    Also note that RHEL6.0 complete OS installation is required for MSM to work.
		The above mentioned rpm's come as part of RHEL6 OS DVD. These RPM's may need
	    additional dependent RPM's as well, all the dependent RPM's also must be installed on the target system.

	7. Net-SNMP rpm installation is required before we install agent rpms.
		RHEL 4.8:
			net-snmp-5.1.2-18.el4.x86_64.rpm
			net-snmp-utils-5.1.2-18.el4.x86_64.rpm
		RHEL5.4
			lm_sensors-2.10.7-4.el5.x86_64.rpm 
			net-snmp-utils-5.3.2.2-7.el5.x86_64.rpm
			net-snmp-5.3.2.2-7.el5.x86_64.rpm
		RHEL 5.3
			lm_sensors-2.10.7-4.el5.x86_64.rpm
			net-snmp-5.3.2.2-5.el5.x86_64.rpm
			net-snmp-utils-5.3.2.2-5.el5.x86_64.rpm
		RHEL 5.5
			net-snmp-5.3.2.2-9.el5.x86_64.rpm
			net-snmp-utils-5.3.2.2-9.el5.x86_64.rpm
		SLES 11
			net-snmp-5.4.2.1-8.1.x86_64.rpm
			perl-SNMP-5.4.2.1-8.1.x86_64.rpm
	8. In case you are unable to install lsi snmp agent rpms, use rpm -ivh --force *.rpm and 
	   then you can uninstall the lsi rpms using rpm -e *.rpm. 
	9. In case of problems with installing multiple rpms and get into cyclic redundancy issue,
	   one can install all rpms in one command line.
	   (Example: rpm  -ivh net-snmp-5.4.2.1-8.1.x86_64.rpm perl-SNMP-5.4.2.1-8.1.x86_64.rpm)
	10. For VMware 3.5, it is necessary to install libstdc++34-3.4.0-1.i386.rpm before installing
	   MegaRAID Storage Manager(MSM). The rpm can be downloaded from
	   http://rpm.pbone.net/index.php3/stat/4/idpl/1203252/com/libstdc++34-3.4.0-1.i386.rpm.html.
	11.For VMware 4.1, it is necessary to create a softlink as mentioned below before installing
	   MegaRAID Storage Manager(MSM). Run the below command to create the necessary soft link
	   required for MegaRAID Storage Manager(MSM) to work.
	   "sudo ln -sf /lib/libgcc_s.so.1 /usr/lib/vmware/lib/libgcc_s.so.1"


Prerequisite for MSM installation:
==================================
MSM installation scripts also installs the LSI SNMP agent rpm. 
The LSI SNMP agent application depends upon standard SNMP Utils package. 
Please ensure that the SNMP-Util package is present in the system before
installing MSM. SNMP-Util package includes the rpm.s net-snmp-libs , net-snmp-utils  and
additional dependent RPM.s. Please make sure that these RPM.s are installed from the OS media before
installing the MSM.

Prior to install MSM, check for existence of libstdc++.so.5 and libstdc++.so.6
librareis are present in /usr/lib directory. If not present/ installed, 
then install the Linux software component RPM that provides these libraries.
These RPM's will be available in the OS DVD. 

Prior to executing install.csh, check for existence of /bin/csh. If
not present/ installed, then install the Linux software component RPM
that provides /bin/csh.

Suppose Lib_Utils rpm is already installed on the target system, irrespective
of the version of the MSM, uninstall the Lib_Utils rpm and then install MSM.

Prerequisites to run MSM remote admin
======================================

1. Configure the system with valid IP address. Make sure there is no IP address conflict with in the sub network.

2. Ports such as 3071 and 5571 are open and available for MSM framework communication.

3. Disable all security manager and firewall.

4. Configure the multicasting, make sure class D multicast IP addresses are registered (at least 229.111.112.12 should be register for MSM to work), if not create static route using the following command:

        route add 229.111.112.12 dev eth1.

        Note that this command will not modify the routing table to be persistent across reboots. Please follow the guidelines per operating system to add the above mentioned IP address as a static entry into the routing table to be persistent across reboots.

        You may wish to add the entire range of IP addressess (224.0.0.0 through 239.255.255.255) into the routing table. Please note that this requires procedures that varies between different flavours and versions of operating system and may have security implications.

5. Install MSM, if already installed then restart MSM framework.


CIMPlugin Support
=================
In case of networks that doesn't have DNS configured, the .hosts. file of the systems where MSM is installed must be manually edited to map the IP address & the host name of your CIMOM server.  In addition, it should also have a mapping of its own IP address (not the loop back address) and host name for the indications to be supported.


MSM Uninstallation
==================
The product can be uninstalled using "Uninstall" short-cut created in Program menu. The user may also directly run the script "/usr/local/MegaRAID Storage Manager/uninstaller.sh" to uninstall MSM.


Notes:
  1. MSM upgrade is supported in this release. In other word, this release can be upgraded by future releases.

  2. To shutdown MSM Framework service, run "/etc/init.d/vivaldiframeworkd stop". It is advisable to stop Monitor service before stopping MSM Framework service. To stop Monitor service run "/etc/init.d/mrmonitor stop".
  
  3. "Any kernel upgrade requires restart of the MSM Framework and Services"
      for example, 
      RedHat Linux command to reload or restart network (login as root user):
      To start Linux network service:
      # service network start
      Debian Linux command to reload or restart network:
      # /etc/init.d/networking restart

********************************************************************
    LSI SNMP agent for Linux 
********************************************************************

Installation procedure for LSI SNMP Agent(For SUSE and Red Hat Linux)
--------------------------------------------------------------------------

1. LSI SNMP Agent rpm's installs the agents. 

2. rpm will take care of the necessary modification needed in the snmpd.conf
file for running the agent.
[
NB: Before installation please check,there is any pass command 
    starts with 1.3.6.1.4.1.3582 OID in snmpd.conf, if available then delete
all the old pass commands starts with 1.3.6.1.4.1.3582 OID.
(This could be possible if there is any previous LSI SNMP Agent was installed
in the system)
]
3. The snmpd.conf file structure should be same as lsi_mrdsnmpd.conf. For
reference,a sample conf file (lsi_mrdsnmpd.conf) will be there in the
/etc/lsi_mrdsnmp directory. 

4. For running SNMP query from a remote m/c add the ip address of that m/c in
the snmpd.conf file like this..

   com2sec	snmpclient	172.28.136.112		public

   Here ipaddress of the remote m/c is 172.28.136.112

5. For receiving snmp trap to a particular m/c, add the ip address of that m/c
in the com2sec section of snmpd.conf file. For example, to get Trap in
10.0.0.144, then add following line to snmpd.conf.
#       sec.name	source			community
   com2sec	snmpclient	10.0.0.144		public

6. To Run/stop the snmpd daemon.
   	/etc/init.d/snmpd start/stop
 
7. To start/stop the SNMP Agent daemon before issuing any snmp query.
     /etc/init.d/lsi_mrdsnmpd start/stop

8. Status of the SNMP Agent daemon can be checked by issuing the following
command...
   /etc/init.d/lsi_mrdsnmpd status

9. You can issue snmp query like this...

    snmpwalk -v1 -c public localhost .1.3.6.1.4.1.3582

10. You can get the snmp trap from local m/c by issuing the following
command...
    snmptrapd -P -F "%02.2h:%02.2j TRAP%w.%q from %A %v\n" 

11. For SLES-11 platform, please follow the below steps to configure traps.
	Edit /etc/lsi_mrdsnmp/sas/sas_TrapDestination.conf file & add ipaddress as
	shown below.

	#################################################
	# Agent Service needs the IP addresses to sent trap
	# The trap destination may be specified in this file or
	# using snmpd.conf file. Following indicators can be set
	# on "TrapDestInd" to instruct the agent to pick the IPs
	# as the destination.
	# 1 - IPs only from snmpd.conf
	# 2 - IPs from this file only
	# 3 - IPs from both the files
	#################################################
	TrapDestInd 3
	#############Trap Destination IP##################
	127.0.0.1   public
	172.28.157.149 public
	#################################################
	
NOTE:
	For SNMP components to work, it is necessary that linux system should
have snmp-net packages(rpm) to be already present.

	It is assumed that snmpd.conf is located at /etc/snmp for Redhat and
/etc for SuSE. Anyway, user can change the file location from
/etc/init.d/lsi_mrdsnmpd file

	It is neccessary to uninstall all the previous version before
installing a new version. The rpm has not been created to support -U version.
The rpm -U is most likely to fail with this rpm.

SNMP Trap Disable functionality
===============================
User may disable SNMP Trap functionality using "-notrap" as install(install.csh) parameter.

MegaRAID Storage Manager(MSM) Installation on VMware :
======================================================
To, install the MSM on VMWare operating system, the user should execute the
command "./vmware_install.sh" from the installation disk.

The installer provides the user to choose the License agreement,operating system 
and storelib to be used as mentioned below.
1. End user license agreement.
2. Operating system  (VMware 3.5 or VMware 4.0).
3. Select the Storelib (Inbox Storelib or Storelib from MSM package).

Note:
1. LSI SNMP Agent is not a supported configuration on VMware Operating system (VMware 3.5 or VMware 4.0).
2. There is a possibility that the MSM Framework that runs on the host from which the GUI is launched misses
   to discover an ESXi host in the subnet, while some other MSM Framework in the same subnet succeeds to discover it.
   In that scenario, all the communications to the ESXi hosts happens through the latter MSM Framework.
   This will result in MSM GUI not receiving events from the ESXi host.

MegaRAID Storage Manager(MSM) Uninstallation on VMWare :
======================================================
The MSM can be uninstalled by running the script 
"/usr/local/MegaRAID Storage Manager/uninstaller.sh".

Note:
=====
When the user runs the MegaRAID Storage Manager(MSM) installation script
install.csh, the rpm's <Lib_Utils-1.xx-xx.noarch.rpm> and <Lib_Utils2-1.xx-xx.noarch.rpm>
will be installed, These RPM's install the third party libraries and MSM is dependent on these
libraries.If you uninstall the libraries installed by these RPM's then other
applications that are dependent on these libraries may not function correctly. Hence these RPM's
will not be removed when MSM is uninstalled. If you want to remove the RPM,
run the command Rpm -e <Lib_Utils-1.xx-xx.noarch.rpm> and
Rpm -e <Lib_Utils2-1.xx-xx.noarch.rpm>.

If older version of the libutil rpm <Lib_Utils-1.xx-xx.noarch.rpm> is
installed on the system, please uninstall the older version of the RPM using the command "rpm -e
<Lib_Utils-1.xx-xx>" and then install the latest libutil rpm <Lib_Utils-1.xx-xx.noarch.rpm>
packaged in this zip file.

MSM Performance improvement
===========================
For better performance of MSM, when subjected to any heap-intensive (say heavy
IOs) or computational tasks,improve the heap by including the following command
"-Xms1024m -Xmx1024m",where
 1024m           Size of the heap allocated. The specified size is dependent on the machine's Hardware configuration.
 -Xms1024m       Sets the initial size of the Java heap to 1024 Mbytes
 -Xmx1024m       Sets the maximum heap size to 1024 Mbytes

 1. Goto product home folder (/usr/local/MegaRAID Storage Manager).
 2. Open startupui.sh file in editable mode.
 3. Include the command -Xms1024m -Xmx1024m after "./jre/bin/java",
    effectively:
    LD_LIBRARY_PATH=$MSM_HOME/lib ./jre/bin/java -Xms1024m -Xmx1024m -DVENUS=true....

=============
Fixes/Updates
=============
11.06.00.05

Repackaged with the latest MegaCLI for vmware platform. In Previous MSM
releases Linux MegaCLI was packaged for vmware platforms.

11.06.00.03

1) LSIP200150265	MSM "create virtual drive" button is enabled even after creating maximum 8 VD's on SWR.
2) LSIP200150202	MSM v11.06.00-0200 Host server IP not resolved - 127.0.0.1
3) LSIP200150354	RWC2: Intel MSM not see the licence agreement in Solaris X86
4) LSIP200148956	MSM require to reboot system when do upgrade or uninstall
5) LSIP200149634	MSM 11.06.00.0200 can not be opened after upgrading from MSM 11.05.01.0200
6) LSIP200150325	RWC2: instead of RWC2, "MSM" is mentioned in solaris read me file.
7) LSIP200149614	Macon:"Start Patrol Read" is disabled in MSM if rebuild in progress (i.e PR cannot be started on non rebuild drives)
8) LSIP200149870	(RW LSIP200148304) macon: option to save TTY log comes for swr controller.
9) LSIP200149868	(RW LSIP200149027) MACON: MSM changes its default write policy for the sencond VD while creating 2 vd's in same time.

11.06.00.02

Enhancements:
1) LSIP200156122        : Need OEM license agreement in their version of MSM

Defects:
1) LSIP200148369        : MACON: under "manage" the option to start init/cc is active when there are no vd's.
2) LSIP200148771        : Macon: MSM throws wrong error message on startin PR while rebuild is in progress for spanned array(raid10)
3) LSIP200148692        : MACON: the server profile page is not alligned properly.
4) LSIP200148304        : macon: option to save TTY log comes for swr controller.
5) LSIP200149027        : MACON: MSM changes its default write policy for the sencond VD while creating 2 vd's in same time.
6) LSIP200148360        : MACON: Set VD properties not available in MSM for VDs in MSM
7) LSIP200148975        : MACON: update firmware option is enabled for the SWR controller in dashboard.
8) LSIP200148309        : MACON: option "suspend patrol read" dosent work in group show progress window
9) LSIP200148207        : SWR:Macon: Group Consistency Check Tab is not displayed for SWR controller
10)LSIP200149008        : RAID Web Console Version 2-9.00-00 doesn't invoke properly on RHEL5 ; hangs
11)LSIP200149339        : Cannot migrate R6 to R5 if use all the drive 
12)LSIP200171613        : After enclosure element event, MSM must manually be refreshed to show new enclosure element status
13)LSIP200169988        : (HSA0xxx)MSM : When install MSM v8.31-00 by silent installation, the login screen with IP 127.0.0.1 appears.
14)LSIP200148826        : 11M05 : SNMP packages gets installed along with VMware MSM installation on ESX 4.1
15)LSIP200113436        : Cisco-ESXi4.1 and ESX4.1 on Alpline/Drake cannot be managed by remote MSM Client
16)LSIP200049941        : MSM on guest OS intermittently has issues showing event/progress updates
17)LSIP200070385        : ESXi- Simultaneous 64VDs Initialization does not work

11.05.01.02

1)	LSIP200148014	: HWR: During the RWC2 11.05.01-01 installation on linux platform, SAS_IR SNMP installation fails.
2)	LSIP200147561	: MSM failed to upgrade to current version on SLES 9.4/X86
3)	LSIP200147869	: 11M05-MSM : Framework crashes after clicking on the controller in vmware ESX 4.1
4)	LSIP200148291	: Dummy defect to resolve merge issues in CIMPlugin


11.05.01.01

1)	LSIP200172699 :(34906.1) No Instant Secure Erase Menu On The MSM With FDE Drive
2)	LSIP200173677 :In MSM, Manage Snapshot Window is out of screen on top part.
3)	LSIP200171128 :Cannot tell which VD's are associated with SSC VD
4)	LSIP200147420 :SWR: Macon-RWC2/MSM hangs when refresh button is pressed after logging in.
5)	LSIP200147651 :(RW LSIP200172680) (34906.1)Drive Erase Menu Didn't Showed For Non SED Drives In MSM
6)	LSIP200156326 : While sending Test Mail, if wrong IP is entered then, MSM hangs on Solaris
7)	LSIP200165901 :MSM displays incorrect message on "Create CacheCade" window
8)	LSIP200147488 :MSM: SNMP is not working when sasIRsnmp package is installed.
9)	LSIP200158444 :WT: Firmware allows to dissociate Blocked Source VD
10)	LSIP200171371 :MSM: Clear configuration is not happening on IR2 controller
11)	LSIP200061012 :With the controller containing Pinned Cache no Pop-up message is thrown by MSM during a FW flash .
12)	LSIP200171304 :MSM: when caching is enable on VD msm doent show error message.
13)	LSIP200171324 :MSM: MSM gives an option to change the power setting for an IR2 card


11.05.01.00

Defects:
1)	LSIP200172774	Dummy defect to check-in changes in CimPlugin
2)	LSIP200168206	(RW LSIP200123954) (RW LSIP200122654) (RW LSIP200121781) MSM only allows the first 16 JBOD to be convert to Unconfigured
3)	LSIP200098660	(Defer LSIP200097351) MSM showing pd clear progress in dashboard while doing full init on VD
4)	LSIP200153839: a connected MSM GUI client (client only v8.16-01) is unable to configure email alerts from the Tools menu 


11.05.00.02

Defects:
1)	LSIP200167062	Defect to checkin 'fullFGDisallow' implementation in group initialization dialog
2)	LSIP200166690	(RW LSIP200139478) MSM: Create Snapshot dialog shows big virtual drive list box
3)	LSIP200167554	Enclosure temperatures are reported 20 deg C higher than actual temperature.
4)	LSIP200166689	(RW LSIP200139183) MSM:Advanced Software Options link  to external website is not working
5)	LSIP200085361	Open MSM will cause MSM to perform a PHY set on Phy 17 with speed 255
6)	LSIP200167013	MSM is ignoring the option "This server requires authentication".
7)	LSIP200165314	MSM does not show correct date in pop up Windows(Alerts)
8)	LSIP200144145	PD labelling is not proper in the MSM event logs.
9)	LSIP200145489	SWR: Macon -In MSM from Manage option  unable to select the virtual drives for intilisation.
10)	LSIP200167075 	Dummy Defect : Unsupported feature Access policy has been observed in VD Properties Panel for IR and WH controllers
11)	LSIP200167102	Dummy Defect SCGCQ00185582 - Unable to Clear Controller Configuration in MSM 11.05.00.00
12)	LSIP200167406	MSM IT Support: Unsupported fields to be addressed in MSM

11.05.00.01

Defects:

1)	LSIP200164086	Cache Offload support revF - MSM does not display Capacitance.
2)	LSIP200159461	Defect to checkin 'fullFGDisallow' implementation
3)	LSIP200158962	MSM reports incorrect number of eligible JBOD drives for conversion.
4)	LSIP200164112	MSM: Unable to update controller firmware
5)	LSIP200155448	CacheOffload : MSM VD property does not get refresshed , not showing proper write policy when battery is removed.
6)	LSIP200155066	CacheOffload : reason for difference in write policy shows blank space when pinned cache is present.
7)	LSIP200155049	CacheOffload :Enable SSD caching windows popup on non cachecade controller.
8)	LSIP200153364	CacheOffload : CaheOffload related events are not comming in MSM.
9)	LSIP200163924	MSM Windows complete installed able to detect and connect to  SLES MSM local

11.05.00.00

Defects:

1)LSIP200123862:Dummy Defect: Error code 0x5015 when attempting to flash incorrect package on WH board using MSM
2)LSIP200120709:MSM UX document is not as per PR
3)LSIP200143166:MSM does not grey out remaining disks when 16 disks are selected to convert to unconfigured good from JBOD.
4)LSIP200156703:Typo "Configured Shiled" in MSM log window
5)LSIP200159187:Dummy defect for IBM Enclosure PR
6)LSIP200156830:MSM Support for IT2 FW
7)LSIP200156069:MSM does not show all ongoing operations on PD
8)LSIP200139478:MSM: Create Snapshot dialog shows big virtual drive list box
9)LSIP200139183:MSM:Advanced Software Options link  to external website is not working
10)LSIP200155841:MSM is unable to show the progress information of copyback operation.
11)LSIP200123307:MSM : There is no proper update on progress bar  in dash board while running some operation
12)LSIP200113299:In MSM Enclosure properties are not as per PR
13)LSIP200113936:MSM 8.17.01 fails to set the link speed with Keyboard only, mouse ok.
14)LSIP200124941:Can not do reconstruction from 11R6 to PRL11 by adding one more drive
15)LSIP200158298: Linux MSM Installation does not show all numeric options


11.02.00.00

Enhancements:

1)LSIP200072140      SW licensing. Support FoD for PF activations on MegaRAID
2)LSIP200084195      Add new Event to notify "Patrol Read Aborted" in MegaRAID FW.

Defects:

1)LSIP200152139:(Defer LSIP200142122) when MSM is launched select "go to" tab ,here all the entities are enabled.
2)LSIP200123862:Dummy Defect: Error code 0x5015 when attempting to flash incorrect package on WH board using MSM
3)LSIP200137431:CDROM  icon does not remove after disconnected the cdrom from the controller.
4)LSIP200122690:MSM : Under background operations in dash board , the progress for VD erase shows twice for a single operation.
5)LSIP200146605:MSM is not allowing user to login in Local Mode
6)LSIP200141089:When you try to create configuration on iMR controller with just JBOD drives present it does not work.
7)LSIP200139478:MSM: Create Snapshot dialog shows big virtual drive list box
8)LSIP200141069:Cannot change Link Speed in MSM for Solaris
9)LSIP200139183:MSM:Advanced Software Options link  to external website is not working
10)LSIP200123307:MSM : There is no proper update on progress bar  in dash board while running some operation
11)LSIP200146030:(Defer LSIP200139740) Unable to change link speed using keyboard in MSM
12)LSIP200125002:MSM: Abort option is not showing for suspended Copy back
13)LSIP200138224:(RW LSIP200124997) HII not showing property "SSD Cache"
14)LSIP200123320:Dummy Defect for chekin new image
15)LSIP200124426:EHSP:Foreign drives showing as emergnecy hotspare eligible
16)LSIP200123596:(RW LSIP200120735) Disk Cache Policy fails to change when SSD drive becomes part of HDD drive group.
17)LSIP200123877:(RW LSIP200122189) Copyback operation suspend Resume functionality not working properly
18)LSIP200141782:This defect is to check-in the PR changes:LSIP200122937,LSIP200122938
19)LSIP200139077:Dummy defect to resolve the merge conflicts
20)LSIP200124598:After reboot or refresh suspended Rebuild or copyback operations is not showing in" show progress" window
21)LSIP200144189:This defect is to resolve the merge changes
22)LSIP200121146:Cacheoffload - Battery type and Firmware version needs to be displayed.
23)LSIP200121525:Resume all is not coming up after OCR
24)LSIP200102355:(Defer LSIP200099384) SNMP not working properly in MSM build 8.15-04 in SPARC

11.20-01

1)LSIP200122912:MSM missing warning box When assign a Dif drive to a Non Pi VD
2)LSIP200124485:Dummy defect to fix the merge issues
3)LSIP200122476:Battery state option in MSM is not as per UX document
4)LSIP200114493:For Patrol read Suspend Resume buttons not available
5)LSIP200122429:Battery retention time is not as per UX document in MSM
6)LSIP200122427:BBU temperature shows "high" in MSM but all other application shows normal.
7)LSIP200122474:Battery replacement field in MSM is not as per UX
8)LSIP200122930:Parity Size calculation for RAID 50 is wrong in MSM.
9)LSIP200123320:Dummy Defect for chekin new image
10)LSIP200122192:For Rebuild operation after performing suspend suspendall is not grayed out in MSM
11)LSIP200122199:Device tree not getting updated after rebuild complete and changing unconfigured bad to good
12)LSIP200121146:Cacheoffload - Battery type and Firmware version needs to be displayed.
13)LSIP200122934:CLI Payload which is incorporated with the MSM is not the 11M02 CLI Payload.

11.20-00

1)LSIP200111886:MSM : MSM not showing BBU
2)LSIP200118901:MSM fails to select PDs seperately.
3)LSIP200121157:(RW LSIP200119487) BBU status option is missing in SNMP
4)LSIP200118962:MRmonitor prints wrong string for commisioned Hot Spare
5)LSIP200121873:Defect to resolve the merge conflicts
6)LSIP200119250:Unable to create new virtual drive using free capacity on existing drive group in MSM
7)LSIP200120324:MSM : resume/suspend option for Reconstruction is present.
8)LSIP200120962:snmp: Rebuilded online PD showing as Emergencyspare
9)LSIP200119423:(RW LSIP200113336) Emergency hotspare field shows "ineligible" for eligible PDs for EHS
10)LSIP200114494:PD/VD Progress panels in Dashboard are not removed after passing the operations
11)LSIP200120693:Disk Cache Policy is shown as "Enabled" in MSM
12)LSIP200119247:Diagnostics complete time string should be changed to diagnostics complete date in MSM.
13)LSIP200120690:MSM: "Resume All" is not enabled on suspending the BGI
14)LSIP200118804:Exception error when create Simple config with mix drive and DIF option
15)LSIP200120961:SNMP: PD property Emergencyspare shows wrong value for eligible EHS PDs
16)LSIP200113885:Emergency hotspare properties getting disabled after change any controller property
17)LSIP200118916:Shielded PD state is shown as null in MSM.
18)LSIP200120008:MSM : MSM Dashboard , does not show PD or VD erase progress in "Background Operation" tab.
19)LSIP200113656:MSM : Group progress still shows the progress bar of the PR operation which got aborted , and application hangs
20)LSIP200113811:MSM not able to import DIF config
21)LSIP200120371:msm: "Abort All" is not getting disabled after "Suspend all"
22)LSIP200119203:Unable to create spanned volume in MSM
23)LSIP200120726:MSM: Suspend All showing for Initialization
24)LSIP200121160:Mirror data is shown as Redundant data in SNMP

8.20-01
1)LSIP200113686:"Emergency Hotspare" field is shown for online PDs
2)LSIP200114039:MSM: While VD reconstruction running "Show Progress" shows "Resume" button instead of "Suspend"
3)LSIP200111877:MSM is showing the PD erase option on configured and HSP's
4)LSIP200113294:MSM is failing to discover host in Suse Linux 11 SP 1.
5)LSIP200113637:Commissioned Hotspare field is shown for all the PDs
6)LSIP200113084:MSM : "Virtual Drive Erase" option available on the right click of an offline VD.
7)LSIP200111913:MSM allows PD's that are under going secure erase fucntion in the PD slection window while creating a configuration
8)LSIP200113690:MSM : VD erase option shown on a VD undergoing initialization.
9)LSIP200113120:MSM : The Description field for "Normal " in the erase mode selection page is improperly complete.
10)LSIP200113683:PD property shows "No" for a commissioned HSP
11)LSIP200113362:MSM fails to perform suspend/resume operations
12)LSIP200111061:MSM 8.17-0100 Create Simple VD Wizard does not show any available raid levels
13)LSIP200113112:MSM : VD erase and PD erase  option still available when the operation is already running on the VD and PD respectively.
14)LSIP200113318:Shield state supported string is missing in Controller property.
15)LSIP200113336:Emergency hotspare field shows "ineligible" for eligible PDs for EHS
16)LSIP200113313:MSM event shows incorrect information
17)LSIP200112700:MSM : Option for secure erase on VD is available on right click of the VD , even when the operation is on progress
18)LSIP200113676:MSM : VD erase option is available on a snapshot VD, which should not be.
19)LSIP200113692:Suspend/resume functionality has not been implemented for BGI
20)LSIP200114026:MSM : "Disk Cache Policy" is grayed out for HDD PD DG
21)LSIP200112282:MSM should not allow to pick non-DIF drive during configuration wizard
22)LSIP200113681:MSM : Mode selection for VD erase , does not contain the "Delete Virtual Drive after Erase" check box as per the UX doc.
23)LSIP200112785:DIF: MSM create error 63 when create R60 with 5 PD in each span
24)LSIP200114065:SNMP : PD erase / abort events not available in trap
25)LSIP200114067:SNMP : VD erase / abort events not available in trap

8.20-00
Enhancements:
1)LSIP200014987:Request to use Unconfigured Good Drives for a HotSpare if no spare defined.
2)LSIP200045037:Emergency spare may ignore mixing policies
3)LSIP200045038:EHSP - Emergency Hot Spare
4)LSIP200045058:DGs revertible HSP attributes sticky on adoption.
5)LSIP200045044:Suspend function, resume function.
6)LSIP200045047:Suspend / resume background tasks
7)LSIP200049184:SSD Cache properties improvements
8)LSIP200049186:Rebuild Write Cache
9)LSIP200049215:PD secure erase
10)LSIP200049226:erase vd function
11)LSIP200049201:PD diag state - Shield State
12)LSIP200049239:MSM improvement for battery display
13)LSIP200049241:Battery alerts
14)LSIP200049245:addtional VD properties for MSM
15)LSIP200049251:enclosure reporting improvements for GUI tools
16)LSIP200049272:MSM installers to include CLI payload
17)LSIP200056054:StoreLib libraries need the capability to be installed with more than one version simultaneously
